from colormate.main import Theme
